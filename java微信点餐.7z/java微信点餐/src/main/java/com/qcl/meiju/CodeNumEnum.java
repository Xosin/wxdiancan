package com.qcl.meiju;

/**
 * ------
 */
public interface CodeNumEnum {
    Integer getCode();
}
