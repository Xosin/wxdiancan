package com.qcl.global;

/**
 * ------
 * 一些全局的常量
 */
public interface GlobalConst {
    String COOKIE_TOKEN = "xosin";//用来管理Cookie的key
    /*
    * 小程序相关
    * */
    String APPID="wx451f647cbc5a1008";//小程序的appid
    String APPSECRET = "468b03be553b2b98e6d28d1bcd4cdacb";//小程序的appsecret

}
