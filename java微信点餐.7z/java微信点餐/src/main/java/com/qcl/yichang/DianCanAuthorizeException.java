package com.qcl.yichang;

/**
 * ------
 */
public class DianCanAuthorizeException extends RuntimeException {
}
