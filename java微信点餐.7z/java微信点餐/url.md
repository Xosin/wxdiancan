
- 可以通过这个链接进入后台
```
http://localhost:8080/diancan/leimu/list
```
